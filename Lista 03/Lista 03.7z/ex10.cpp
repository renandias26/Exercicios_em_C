//Apresentar uma palavra alternada entre mai�sculo e min�sculo, de 5 a 10 caracteres
#include <stdlib.h>
#include <stdio.h>
#include <locale.h>
#include <string.h>
#include <ctype.h>

int main(){
	setlocale(LC_ALL, "portuguese");
	
	char palavra[50];
	int x;
	
	do{
		printf("Digite uma palavra, com no m�nimo, 5 caracteres, e no m�ximo 10 caracteres: ");
		gets(palavra);
		x=strlen(palavra);
	}
	while ((x<5)||(x>10));
	
	for(int y=0; y<x; y++){
		if(y%2!=0){
			printf("%c", tolower(palavra[y]));
		}else{
			printf("%c", toupper(palavra[y]));
		}
	}
	
	return 0;
}
